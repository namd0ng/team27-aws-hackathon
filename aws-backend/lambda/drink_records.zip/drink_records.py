import json
import boto3
import uuid
from datetime import datetime
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('alcolook-drink-records')

def lambda_handler(event, context):
    method = event['httpMethod']
    
    try:
        if method == 'POST':
            return create_record(event)
        elif method == 'GET':
            return get_records(event)
        elif method == 'PUT':
            return update_record(event)
        elif method == 'DELETE':
            return delete_record(event)
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def create_record(event):
    body = json.loads(event['body'])
    user_id = body['userId']
    
    record = {
        'userId': user_id,
        'recordId': str(uuid.uuid4()),
        'date': body['date'],
        'drinkType': body['drinkType'],
        'count': body['count'],
        'volumeMl': body.get('volumeMl'),
        'abv': Decimal(str(body.get('abv', 0))),
        'note': body.get('note', ''),
        'analysisProb': Decimal(str(body.get('analysisProb', 0))),
        'createdAt': datetime.utcnow().isoformat()
    }
    
    table.put_item(Item=record)
    
    return {
        'statusCode': 201,
        'body': json.dumps(record, default=str)
    }

def get_records(event):
    user_id = event['queryStringParameters']['userId']
    
    response = table.query(
        KeyConditionExpression='userId = :userId',
        ExpressionAttributeValues={':userId': user_id}
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps(response['Items'], default=str)
    }

def update_record(event):
    body = json.loads(event['body'])
    user_id = body['userId']
    record_id = body['recordId']
    
    table.update_item(
        Key={'userId': user_id, 'recordId': record_id},
        UpdateExpression='SET #dt = :dt, #c = :c, #vm = :vm, #abv = :abv, #note = :note',
        ExpressionAttributeNames={
            '#dt': 'drinkType',
            '#c': 'count',
            '#vm': 'volumeMl',
            '#abv': 'abv',
            '#note': 'note'
        },
        ExpressionAttributeValues={
            ':dt': body['drinkType'],
            ':c': body['count'],
            ':vm': body.get('volumeMl'),
            ':abv': Decimal(str(body.get('abv', 0))),
            ':note': body.get('note', '')
        }
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Updated successfully'})
    }

def delete_record(event):
    user_id = event['queryStringParameters']['userId']
    record_id = event['queryStringParameters']['recordId']
    
    table.delete_item(
        Key={'userId': user_id, 'recordId': record_id}
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Deleted successfully'})
    }
